
SONGS = [
    # Pop
    {"song": "Espresso", "artist": "Sabrina Carpenter", "genre": "Pop",
     "tags": ["main_character", "unbothered", "curated", "aloof", "healthy"],
     "energy": 0.85, "valence": 0.9, "vibe": "that girl energy"},

    {"song": "Nonsense", "artist": "Sabrina Carpenter", "genre": "Pop",
     "tags": ["main_character", "down_bad", "chaotic", "hype_energy", "healthy"],
     "energy": 0.8, "valence": 0.88, "vibe": "flirty chaos"},

    {"song": "Flowers", "artist": "Miley Cyrus", "genre": "Pop",
     "tags": ["healing", "unbothered", "villain", "curated", "gen_z_text"],
     "energy": 0.75, "valence": 0.82, "vibe": "self-love era"},

    {"song": "Cruel Summer", "artist": "Taylor Swift", "genre": "Pop",
     "tags": ["down_bad", "main_character", "obsessive", "dreamer", "oversharer"],
     "energy": 0.9, "valence": 0.7, "vibe": "pining chaos"},

    {"song": "Anti-Hero", "artist": "Taylor Swift", "genre": "Pop",
     "tags": ["rotting", "healing", "emotional", "oversharer", "gen_z_text"],
     "energy": 0.6, "valence": 0.45, "vibe": "self-aware spiral"},

    # Hip-Hop
    {"song": "Not Like Us", "artist": "Kendrick Lamar", "genre": "Hip-Hop",
     "tags": ["villain", "unbothered", "hype_energy", "curated", "aloof"],
     "energy": 0.95, "valence": 0.6, "vibe": "certified villain"},

    {"song": "Luther", "artist": "Kendrick Lamar ft. SZA", "genre": "Hip-Hop",
     "tags": ["obsessive", "down_bad", "dreamer", "emotional", "oversharer"],
     "energy": 0.55, "valence": 0.65, "vibe": "soft obsessive"},

    {"song": "Rich Flex", "artist": "Drake & 21 Savage", "genre": "Hip-Hop",
     "tags": ["main_character", "villain", "hype_energy", "chaotic_shuffle", "aloof"],
     "energy": 0.88, "valence": 0.72, "vibe": "flexing on everyone"},

    {"song": "fukumean", "artist": "Gunna", "genre": "Hip-Hop",
     "tags": ["villain", "unbothered", "aloof", "healthy", "chaotic_shuffle"],
     "energy": 0.82, "valence": 0.68, "vibe": "unbothered villain"},

    # R&B
    {"song": "Good Days", "artist": "SZA", "genre": "R&B",
     "tags": ["healing", "dreamer", "emotional", "gen_z_text", "rotting"],
     "energy": 0.45, "valence": 0.5, "vibe": "hopeful melancholy"},

    {"song": "Kill Bill", "artist": "SZA", "genre": "R&B",
     "tags": ["obsessive", "down_bad", "villain", "oversharer", "emotional"],
     "energy": 0.65, "valence": 0.4, "vibe": "unhinged in love"},

    {"song": "Snooze", "artist": "SZA", "genre": "R&B",
     "tags": ["down_bad", "dreamer", "obsessive", "emotional", "oversharer"],
     "energy": 0.5, "valence": 0.55, "vibe": "lovesick and aware"},

    {"song": "Creepin'", "artist": "Metro Boomin ft. The Weeknd", "genre": "R&B",
     "tags": ["chaotic", "in_denial", "gremlin", "aloof", "villain"],
     "energy": 0.7, "valence": 0.38, "vibe": "late night chaos"},

    # Indie
    {"song": "as it was", "artist": "Harry Styles", "genre": "Indie",
     "tags": ["healing", "emotional", "dreamer", "gen_z_text", "rotting"],
     "energy": 0.62, "valence": 0.52, "vibe": "healing but unwell"},

    {"song": "Everywhere, Everything", "artist": "Noah Kahan", "genre": "Indie",
     "tags": ["down_bad", "oversharer", "dreamer", "emotional", "obsessive"],
     "energy": 0.55, "valence": 0.6, "vibe": "soft romantic chaos"},

    {"song": "Stick Season", "artist": "Noah Kahan", "genre": "Indie",
     "tags": ["rotting", "emotional", "dreamer", "in_denial", "gen_z_text"],
     "energy": 0.5, "valence": 0.35, "vibe": "seasonal depression pop"},

    {"song": "Supernatural", "artist": "Gracie Abrams", "genre": "Indie",
     "tags": ["obsessive", "down_bad", "oversharer", "dreamer", "emotional"],
     "energy": 0.48, "valence": 0.42, "vibe": "quietly unraveling"},

    # Electronic
    {"song": "Escapism.", "artist": "RAYE ft. 070 Shake", "genre": "Electronic",
     "tags": ["gremlin", "chaotic", "villain", "rotting", "hype_energy"],
     "energy": 0.78, "valence": 0.35, "vibe": "spiraling in the club"},

    {"song": "Redlight", "artist": "Sub Focus & Dimension", "genre": "Electronic",
     "tags": ["chaotic_shuffle", "hype_energy", "healthy", "main_character", "curated"],
     "energy": 0.92, "valence": 0.75, "vibe": "main character montage"},

    # Sad Girl
    {"song": "Bags", "artist": "Clairo", "genre": "Sad Girl",
     "tags": ["down_bad", "gen_z_text", "dreamer", "obsessive", "emotional"],
     "energy": 0.3, "valence": 0.38, "vibe": "soft down bad"},

    {"song": "Pretty Girl", "artist": "Clairo", "genre": "Sad Girl",
     "tags": ["healing", "rotting", "gen_z_text", "dreamer", "in_denial"],
     "energy": 0.28, "valence": 0.42, "vibe": "bedroom melancholy"},

    {"song": "Motion Sickness", "artist": "Phoebe Bridgers", "genre": "Sad Girl",
     "tags": ["emotional", "oversharer", "healing", "in_denial", "dreamer"],
     "energy": 0.55, "valence": 0.3, "vibe": "artfully devastated"},

    # K-Pop
    {"song": "Magnetic", "artist": "ILLIT", "genre": "K-Pop",
     "tags": ["main_character", "hype_energy", "curated", "healthy", "unbothered"],
     "energy": 0.88, "valence": 0.85, "vibe": "effortlessly iconic"},

    {"song": "Seven", "artist": "Jung Kook ft. Latto", "genre": "K-Pop",
     "tags": ["down_bad", "chaotic", "gremlin", "hype_energy", "obsessive"],
     "energy": 0.85, "valence": 0.78, "vibe": "chaotic in love"},

    # Latin
    {"song": "Shakira: Bzrp Music Sessions #53", "artist": "Bizarrap & Shakira", "genre": "Latin",
     "tags": ["villain", "unbothered", "healing", "main_character", "aloof"],
     "energy": 0.82, "valence": 0.72, "vibe": "revenge served cold"},

    {"song": "La Bebe", "artist": "Yng Lvcas & Peso Pluma", "genre": "Latin",
     "tags": ["main_character", "hype_energy", "chaotic_shuffle", "healthy", "curated"],
     "energy": 0.9, "valence": 0.88, "vibe": "zero apologies"},

    # Afrobeats
    {"song": "Calm Down", "artist": "Rema & Selena Gomez", "genre": "Afrobeats",
     "tags": ["down_bad", "main_character", "chaotic", "hype_energy", "obsessive"],
     "energy": 0.84, "valence": 0.82, "vibe": "obsessed and thriving"},

    {"song": "Essence", "artist": "Wizkid ft. Tems", "genre": "Afrobeats",
     "tags": ["dreamer", "down_bad", "healing", "curated", "emotional"],
     "energy": 0.72, "valence": 0.8, "vibe": "smooth obsession"},

    # Rock
    {"song": "Vampire", "artist": "Olivia Rodrigo", "genre": "Rock",
     "tags": ["villain", "healing", "oversharer", "emotional", "in_denial"],
     "energy": 0.78, "valence": 0.3, "vibe": "poetic chaos"},

    {"song": "good 4 u", "artist": "Olivia Rodrigo", "genre": "Rock",
     "tags": ["villain", "chaotic", "hype_energy", "healing", "unbothered"],
     "energy": 0.9, "valence": 0.45, "vibe": "passive aggressive icon"},
]
