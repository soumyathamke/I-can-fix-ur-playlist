import streamlit as st
import streamlit.components.v1 as components
import os
import json
import requests as _req
from groq import Groq
from recommender import recommend, get_top_match

st.set_page_config(
    page_title="VibeCheck.ai",
    page_icon="🔪",
    layout="centered"
)

# ── accent colour (swap green → hot pink) ──────────────────
ACCENT      = "#ff2d78"
ACCENT_GLOW = "rgba(255,45,120,0.25)"
ACCENT_DIM  = "rgba(255,45,120,0.12)"
ACCENT_MID  = "rgba(255,45,120,0.45)"

GENRE_AUDIO = {
    "no preference": "",
    "Pop":        "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
    "Hip-Hop":    "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
    "R&B":        "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
    "Indie":      "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
    "Electronic": "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3",
    "Rock":       "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3",
    "Latin":      "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3",
    "K-Pop":      "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3",
    "Afrobeats":  "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3",
    "Sad Girl":   "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3",
}

HOVER_AUDIO = {
    "main_character":    "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
    "rotting":           "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
    "villain":           "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
    "healing":           "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
    "down_bad":          "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3",
    "unbothered":        "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3",
    "chaotic":           "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3",
    "in_denial":         "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3",
    "obsessive":         "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3",
    "curated":           "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3",
    "chaotic_shuffle":   "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-11.mp3",
    "unhinged_creative": "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-12.mp3",
    "gremlin":           "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-13.mp3",
    "emotional":         "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-14.mp3",
    "dreamer":           "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-15.mp3",
    "healthy":           "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-16.mp3",
    "gen_z_text":        "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
    "hype_energy":       "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
    "oversharer":        "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
    "aloof":             "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
}

# ── inject global CSS ───────────────────────────────────────
st.markdown(f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:ital,wght@0,400;0,500;0,600;1,400&display=swap');

html, body, [class*="css"] {{
    font-family: 'DM Sans', sans-serif;
    background: #060606 !important;
    color: #fff;
}}
.stApp {{ background: #060606 !important; }}
#MainMenu, footer, header {{ visibility: hidden; }}
.block-container {{ padding-top: 2.5rem !important; max-width: 560px !important; }}

/* ── TITLE ── */
.vibe-title {{
    font-family: 'Bebas Neue', sans-serif;
    font-size: 72px;
    font-weight: 400;
    text-align: center;
    letter-spacing: 6px;
    line-height: 1.0;
    margin-bottom: 4px;
    /* hot pink → white → hot pink */
    background: linear-gradient(120deg, #ff2d78 0%, #ff85b3 40%, #fff 60%, #ff2d78 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    filter: drop-shadow(0 0 40px {ACCENT_GLOW});
}}
.vibe-sub {{
    text-align: center;
    font-size: 11px;
    color: rgba(255,255,255,0.3);
    letter-spacing: 0.25em;
    text-transform: uppercase;
    margin-bottom: 2.5rem;
    font-weight: 500;
}}

/* ── QUESTION LABEL ── */
.q-label {{
    font-family: 'Bebas Neue', sans-serif;
    font-size: 28px;
    letter-spacing: 2px;
    color: #fff;
    margin-bottom: 1.2rem;
}}

/* ── RADIO → CARDS (quiz) ── */
div[data-testid="stRadio"] > div {{
    display: grid !important;
    grid-template-columns: 1fr 1fr !important;
    gap: 10px !important;
}}
div[data-testid="stRadio"] label {{
    background: rgba(255,255,255,0.04) !important;
    border: 1px solid rgba(255,255,255,0.09) !important;
    border-radius: 16px !important;
    padding: 16px 14px !important;
    color: rgba(255,255,255,0.7) !important;
    font-size: 13px !important;
    font-family: 'DM Sans', sans-serif !important;
    font-weight: 500 !important;
    cursor: pointer !important;
    transition: all 0.18s ease !important;
    line-height: 1.45 !important;
    min-height: 68px !important;
    display: flex !important;
    align-items: center !important;
}}
div[data-testid="stRadio"] label:hover {{
    border-color: {ACCENT} !important;
    color: #fff !important;
    transform: translateY(-2px) !important;
    box-shadow: 0 8px 28px {ACCENT_GLOW} !important;
    background: {ACCENT_DIM} !important;
}}
div[data-testid="stRadio"] label:has(input:checked) {{
    border-color: {ACCENT} !important;
    background: {ACCENT_DIM} !important;
    color: {ACCENT} !important;
    box-shadow: 0 0 0 1px {ACCENT} !important;
}}
div[data-testid="stRadio"] input[type="radio"] {{ display: none !important; }}
div[data-testid="stRadio"] label > div:first-child {{ display: none !important; }}
div[data-testid="stRadio"] > label {{ display: none !important; }}

/* ── EYE COUNTER ── */
.eye-counter {{
    position: fixed;
    top: 14px;
    right: 18px;
    z-index: 9999;
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 20px;
    padding: 5px 11px 5px 9px;
    font-size: 12px;
    color: rgba(255,255,255,0.45);
    display: flex;
    align-items: center;
    gap: 5px;
    backdrop-filter: blur(8px);
    letter-spacing: 0.02em;
    pointer-events: none;
    font-family: 'DM Sans', sans-serif;
}}
.eye-counter span {{ font-size: 14px; }}

/* ── GENRE CARDS ── */
.genre-card {{
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.09);
    border-radius: 14px;
    padding: 14px;
    color: rgba(255,255,255,0.75);
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.18s;
    line-height: 1.4;
    user-select: none;
}}
.genre-card:hover {{
    border-color: {ACCENT};
    background: {ACCENT_DIM};
    color: #fff;
    transform: translateY(-1px);
}}
.genre-sel {{
    border-color: {ACCENT} !important;
    background: {ACCENT_DIM} !important;
    color: {ACCENT} !important;
}}

/* ── PROGRESS DOTS ── */
.dots-row {{
    display: flex; gap: 6px; justify-content: center; margin-bottom: 2rem;
}}
.pdot {{
    width: 6px; height: 6px; border-radius: 50%;
    background: rgba(255,255,255,0.12); transition: all 0.3s;
}}
.pdot.active {{ background: {ACCENT}; width: 22px; border-radius: 3px; }}
.pdot.done   {{ background: {ACCENT_MID}; }}

/* ── PILL BUTTON ── */
div.stButton > button {{
    background: {ACCENT} !important;
    color: #fff !important;
    border: none !important;
    border-radius: 999px !important;
    padding: 0.65rem 2rem !important;
    font-weight: 700 !important;
    font-family: 'DM Sans', sans-serif !important;
    font-size: 14px !important;
    letter-spacing: 0.05em !important;
    width: auto !important;
    transition: all 0.2s !important;
    box-shadow: 0 4px 20px {ACCENT_GLOW} !important;
}}
div.stButton > button:hover {{
    background: #ff5599 !important;
    transform: scale(1.04) !important;
    box-shadow: 0 6px 28px {ACCENT_GLOW} !important;
}}


/* ── RESULT CARD ── */
.result-wrap {{
    border-radius: 20px;
    border: 1px solid rgba(255,45,120,0.2);
    background: rgba(255,45,120,0.04);
    padding: 2rem;
    margin: 1rem 0;
    position: relative;
    overflow: hidden;
}}
.result-wrap::before {{
    content: '';
    position: absolute;
    top: -80px; right: -80px;
    width: 240px; height: 240px;
    background: radial-gradient(circle, {ACCENT_GLOW}, transparent 70%);
    pointer-events: none;
}}
.art-img {{
    width: 100px; height: 100px;
    border-radius: 12px;
    object-fit: cover;
    float: right;
    margin: 0 0 1rem 1rem;
    border: 1px solid rgba(255,255,255,0.1);
    box-shadow: 0 4px 20px {ACCENT_GLOW};
}}
.res-song-name {{
    font-family: 'Bebas Neue', sans-serif;
    font-size: 34px;
    letter-spacing: 2px;
    color: {ACCENT};
    line-height: 1.05;
    margin-bottom: 4px;
    filter: drop-shadow(0 0 12px {ACCENT_GLOW});
}}
.res-artist-name {{
    font-size: 14px;
    color: rgba(255,255,255,0.4);
    margin-bottom: 14px;
}}
.vibe-tag {{
    display: inline-block;
    background: {ACCENT_DIM};
    border: 1px solid rgba(255,45,120,0.35);
    border-radius: 999px;
    padding: 4px 14px;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: {ACCENT};
    margin-bottom: 14px;
}}
.res-reason {{
    font-size: 14px;
    line-height: 1.8;
    color: rgba(255,255,255,0.6);
    border-top: 1px solid rgba(255,255,255,0.07);
    padding-top: 1rem;
    clear: both;
}}
.match-info {{
    font-size: 11px;
    color: rgba(255,255,255,0.18);
    margin-top: 1rem;
    letter-spacing: 0.05em;
}}
.yt-btn {{
    display: inline-block;
    margin-top: 1rem;
    color: {ACCENT};
    font-size: 13px;
    font-weight: 600;
    text-decoration: none;
    border: 1px solid rgba(255,45,120,0.3);
    border-radius: 999px;
    padding: 6px 18px;
    transition: all 0.2s;
}}
.yt-btn:hover {{
    background: {ACCENT_DIM};
    color: {ACCENT};
    box-shadow: 0 0 16px {ACCENT_GLOW};
}}
.roast-txt {{
    color: #ff8fab;
    font-size: 13px;
    text-align: center;
    margin: 1.5rem 0 0.5rem;
    font-weight: 500;
    font-style: italic;
}}
.section-lbl {{
    font-family: 'Bebas Neue', sans-serif;
    font-size: 13px;
    letter-spacing: 0.2em;
    color: rgba(255,255,255,0.28);
    margin-bottom: 10px;
}}
</style>
""", unsafe_allow_html=True)


QUESTIONS = [
    {
        "emoji": "🌡️",
        "text": "current mood, no cap:",
        "options": [
            {"label": "main character energy 💅", "tag": "main_character"},
            {"label": "rotting in bed 🛌 send help",  "tag": "rotting"},
            {"label": "villain era, no apologies 😈",  "tag": "villain"},
            {"label": "healing era but also unwell 🌸", "tag": "healing"},
        ]
    },
    {
        "emoji": "📱",
        "text": "ur situationship texts 'hey' at 2am. u:",
        "options": [
            {"label": "reply instantly 💀 we're cooked",       "tag": "down_bad"},
            {"label": "leave on read 3hrs then reply 😏",       "tag": "unbothered"},
            {"label": "screenshot + send to group chat first",  "tag": "chaotic"},
            {"label": "i don't have one (liar)",                "tag": "in_denial"},
        ]
    },
    {
        "emoji": "🚗",
        "text": "alone in the car, aux is yours. u play:",
        "options": [
            {"label": "one song on repeat 30x 😤",        "tag": "obsessive"},
            {"label": "full curated playlist no skips 🎧", "tag": "curated"},
            {"label": "shuffle whatever hits 📻",          "tag": "chaotic_shuffle"},
            {"label": "voice notes to myself lol 🎤",      "tag": "unhinged_creative"},
        ]
    },
    {
        "emoji": "🌙",
        "text": "last thing before sleeping:",
        "options": [
            {"label": "doomscroll tiktok till 3am 📲",      "tag": "gremlin"},
            {"label": "journal / reflect / cry a little ✍️", "tag": "emotional"},
            {"label": "music + stare at ceiling 🌌",         "tag": "dreamer"},
            {"label": "sleep immediately like a dog 🐶",     "tag": "healthy"},
        ]
    },
    {
        "emoji": "💬",
        "text": "how do u text?",
        "options": [
            {"label": "lowercase, no punctuation ever", "tag": "gen_z_text"},
            {"label": "FULL CAPS when excited 🔥",       "tag": "hype_energy"},
            {"label": "walls of text, oversharer",       "tag": "oversharer"},
            {"label": "one word replies, mysterious",    "tag": "aloof"},
        ]
    }
]

GENRES = ["no preference", "Pop", "Hip-Hop", "R&B", "Indie", "Electronic", "Rock", "Latin", "K-Pop", "Afrobeats", "Sad Girl"]

ROASTS = [
    "oh u wanna try again? 💀 what, the first answer hurt ur feelings?",
    "trying again? ur music taste is still broken btw 🔪",
    "not u trying to escape ur own vibe 💀",
    "sir/ma'am this isn't a retry game. but ok 🙄",
    "again?? the audacity 😭 ok fine i'll fix u again",
]

# ── session state ───────────────────────────────────────────
for k, v in [
    ("step", "start"), ("answers", []), ("genre", "no preference"),
    ("result", None), ("retries", 0), ("current_q", 0), ("selected_tag", None),
    ("view_count", None),
]:
    if k not in st.session_state:
        st.session_state[k] = v

# ── hit counter (file-based, once per session) ───────────────
_COUNTER_FILE = ".view_count.json"

def _increment_views():
    try:
        data = {"v": 0}
        if os.path.exists(_COUNTER_FILE):
            with open(_COUNTER_FILE) as f:
                data = json.load(f)
        data["v"] = data.get("v", 0) + 1
        with open(_COUNTER_FILE, "w") as f:
            json.dump(data, f)
        return data["v"]
    except Exception:
        return "—"

if st.session_state.view_count is None:
    st.session_state.view_count = _increment_views()


def generate_roast(song, user_tags, genre):
    try:
        client = Groq(api_key=os.environ.get("GROQ_API_KEY"))
        prompt = f"""You are a sassy Gen Z music expert who just recommended "{song['song']}" by {song['artist']}.
Their vibe tags: {', '.join(user_tags)}. Genre preference: {genre}.
Write 2-3 punchy sentences roasting them. Reference their tags. End with a sassy one-liner.
Mean but loving. Very Gen Z. No hashtags."""
        response = client.chat.completions.create(
            model="llama3-70b-8192",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=200
        )
        return response.choices[0].message.content
    except Exception:
        return f"ur tags literally screamed '{song['vibe']}' and i had no choice. this song found u. ur welcome."


def fetch_album_art(song, artist):
    return f"https://via.placeholder.com/100x100/ff2d78/ffffff?text={song[0]}"


def render_genre_cards(genres, selected_genre):
    """Render plain genre card divs (no event attrs — events attached via JS)."""
    html = '<div class="genre-grid" style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:1rem">'
    for i, g in enumerate(genres):
        extra = " genre-sel" if g == selected_genre else ""
        html += f'<div class="genre-card{extra}" data-gidx="{i}">{g}</div>'
    html += "</div>"
    return html


def attach_genre_audio(genres):
    """
    Inject a components.html iframe that:
    - attaches mouseenter/mouseleave audio to .genre-card divs in the parent frame
    - attaches click to trigger the corresponding hidden radio input
    """
    srcs_json = json.dumps([GENRE_AUDIO.get(g, "") for g in genres])
    components.html(f"""
    <script>
    (function() {{
        var srcs = {srcs_json};
        var _audio = null;
        function play(src) {{
            if (!src) return;
            if (_audio) {{ _audio.pause(); _audio.currentTime = 0; }}
            _audio = new Audio(src);
            _audio.volume = 0.2;
            _audio.play().catch(function(){{}});
        }}
        function stop() {{
            if (_audio) {{ _audio.pause(); _audio.currentTime = 0; }}
        }}
        function attach() {{
            try {{
                var pdoc = window.parent.document;
                var cards = pdoc.querySelectorAll('.genre-card');
                if (!cards.length) return false;
                cards.forEach(function(card, i) {{
                    if (card.dataset.ah) return;
                    card.dataset.ah = '1';
                    card.addEventListener('mouseenter', function() {{ play(srcs[i]); }});
                    card.addEventListener('mouseleave', stop);
                    card.addEventListener('click', function() {{
                        var inputs = pdoc.querySelectorAll('input[type="radio"]');
                        if (inputs[i]) inputs[i].click();
                    }});
                }});
                return true;
            }} catch(e) {{ return false; }}
        }}
        var t = 0;
        var iv = setInterval(function() {{ if (attach() || ++t > 40) clearInterval(iv); }}, 150);
    }})();
    </script>
    """, height=0)


# ═══════════════════════════════════════════════════════════
# START
# ═══════════════════════════════════════════════════════════
if st.session_state.step == "start":
    st.markdown(
        f'<div class="eye-counter"><span>👁</span>{st.session_state.view_count:,}</div>'
        if isinstance(st.session_state.view_count, int)
        else f'<div class="eye-counter"><span>👁</span>{st.session_state.view_count}</div>',
        unsafe_allow_html=True,
    )
    st.markdown('<div style="text-align:center;line-height:1;margin-bottom:4px"><span class="vibe-title">VibeCheck.ai</span> <span style="font-size:38px;vertical-align:middle;-webkit-text-fill-color:initial;background:none">🔪</span></div>', unsafe_allow_html=True)
    st.markdown('<div class="vibe-sub">5 questions. 1 song. no mercy.</div>', unsafe_allow_html=True)

    st.markdown('<div class="section-lbl">pick ur genre (optional)</div>', unsafe_allow_html=True)

    # hidden radio tracks state; genre cards are the visual (events via JS)
    st.markdown('<style>div[data-testid="stRadio"]{display:none!important}</style>', unsafe_allow_html=True)
    genre = st.radio("Genre", GENRES, key="genre_radio", label_visibility="hidden")
    st.session_state.genre = genre

    st.markdown(render_genre_cards(GENRES, genre), unsafe_allow_html=True)
    attach_genre_audio(GENRES)

    st.markdown("<br>", unsafe_allow_html=True)
    if st.button("let's fix it 🎯"):
        st.session_state.step = "quiz"
        st.session_state.current_q = 0
        st.session_state.answers = []
        st.session_state.selected_tag = None
        st.rerun()


# ═══════════════════════════════════════════════════════════
# QUIZ
# ═══════════════════════════════════════════════════════════
elif st.session_state.step == "quiz":
    q_idx = st.session_state.current_q
    q     = QUESTIONS[q_idx]

    # progress dots
    dots_html = '<div class="dots-row">' + "".join([
        f'<div class="pdot {"active" if i == q_idx else "done" if i < q_idx else ""}"></div>'
        for i in range(len(QUESTIONS))
    ]) + '</div>'
    st.markdown(dots_html, unsafe_allow_html=True)

    st.markdown(f'<div class="q-label">{q["emoji"]} {q["text"]}</div>', unsafe_allow_html=True)

    option_labels = [o["label"] for o in q["options"]]
    option_tags   = [o["tag"]   for o in q["options"]]
    choice = st.radio("hidden", option_labels, label_visibility="hidden", key=f"q_{q_idx}")
    chosen_tag = option_tags[option_labels.index(choice)]
    st.session_state.selected_tag = chosen_tag

    st.markdown("<br>", unsafe_allow_html=True)
    col1, col2, col3 = st.columns([1, 1, 1])
    with col2:
        btn_label = "next →" if q_idx < len(QUESTIONS) - 1 else "fix my playlist 🔪"
        if st.button(btn_label):
            st.session_state.answers.append(chosen_tag)
            if q_idx < len(QUESTIONS) - 1:
                st.session_state.current_q += 1
                st.session_state.selected_tag = None
                st.rerun()
            else:
                st.session_state.step = "result"
                st.rerun()


# ═══════════════════════════════════════════════════════════
# RESULT
# ═══════════════════════════════════════════════════════════
elif st.session_state.step == "result":
    user_tags = st.session_state.answers
    genre     = st.session_state.genre if st.session_state.genre != "no preference" else None

    if st.session_state.result is None:
        with st.spinner("diagnosing ur taste..."):
            top   = get_top_match(user_tags, genre_filter=genre)
            roast = generate_roast(top, user_tags, st.session_state.genre)
            top["roast"] = roast
            top["art"]   = fetch_album_art(top["song"], top["artist"])
            st.session_state.result = top

    r = st.session_state.result

    yt_query = f"{r['song']} {r['artist']} official audio".replace(" ", "+")
    yt_url   = f"https://www.youtube.com/results?search_query={yt_query}"

    # fetch real album art via iTunes (client-side JS)
    art_js = f"""
    <script>
    fetch('https://itunes.apple.com/search?term={r["song"].replace(" ","+")}+{r["artist"].replace(" ","+")}&limit=1&entity=song')
      .then(function(res){{ return res.json(); }})
      .then(function(d){{
        if(d.results && d.results[0] && d.results[0].artworkUrl100) {{
          var img = document.getElementById('album-art');
          if(img) img.src = d.results[0].artworkUrl100.replace('100x100bb','600x600bb');
        }}
      }}).catch(function(){{}});
    </script>
    """

    yt_embed = (
        "https://www.youtube.com/embed"
        f"?listType=search&list={yt_query}"
        "&autoplay=1&playsinline=1&rel=0"
    )

    st.markdown(f"""
    <div class="result-wrap">
        <div class="res-song-name">{r['song']}</div>
        <div class="res-artist-name">— {r['artist']}</div>
        <div class="vibe-tag">{r['vibe']}</div>
        <div class="res-reason">{r['roast']}</div>
        <div class="match-info">match score: {r['score']:.0%} &nbsp;·&nbsp; genre: {r['genre']}</div>
        <div style="margin-top:18px;border-radius:14px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.5)">
            <iframe
                src="{yt_embed}"
                width="100%" height="200"
                frameborder="0"
                allow="autoplay; encrypted-media; fullscreen"
                allowfullscreen
                style="display:block;border-radius:14px">
            </iframe>
        </div>
        <a class="yt-btn" href="{yt_url}" target="_blank">↗ open full video</a>
    </div>
    """, unsafe_allow_html=True)

    result_audio_src = HOVER_AUDIO.get(user_tags[-1] if user_tags else "dreamer", "")
    components.html(f"""
    <script>
    (function(){{
        if(window._ra) {{ window._ra.pause(); window._ra.currentTime = 0; }}
        window._ra = new Audio('{result_audio_src}');
        window._ra.volume = 0.07;
        window._ra.loop = true;
        window._ra.play().catch(function(){{}});
    }})();
    </script>
    """, height=0)

    st.markdown("<br>", unsafe_allow_html=True)
    with st.expander("see ur top 3 matches"):
        top3 = recommend(user_tags, genre_filter=genre, top_k=3)
        for i, s in enumerate(top3):
            st.markdown(f"**{i+1}. {s['song']}** — {s['artist']}  `{s['score']:.0%} match` · _{s['vibe']}_")

    roast_line = ROASTS[st.session_state.retries % len(ROASTS)]
    st.markdown(f'<p class="roast-txt">{roast_line}</p>', unsafe_allow_html=True)

    col1, col2, col3 = st.columns([1, 1, 1])
    with col2:
        if st.button("yeah fine, again 😒"):
            st.session_state.step        = "start"
            st.session_state.answers     = []
            st.session_state.result      = None
            st.session_state.current_q   = 0
            st.session_state.selected_tag = None
            st.session_state.retries     += 1
            st.rerun()